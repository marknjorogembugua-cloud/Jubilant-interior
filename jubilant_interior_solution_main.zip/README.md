# Jubilant Interior Solution — Elite Quotation Manager

PC-first Electron desktop software for creating premium interior-design quotations.

## Key features
- Professional A4 PDF quotation export using the Jubilant brand/logo
- Branded quotation status, document number, date, validity and client reference
- Room/zone based quotation lines
- Quantity, unit, rate and automatic totals
- No VAT and no discounts
- Project overview, payment terms, assumptions/exclusions
- Client and project management
- Reusable services/materials catalogue
- Business identity, tagline, website, payment instructions and PDF footer
- JSON backup and restore
- Local persistent data

## Run
```bash
npm install
npm start
```

## Windows installer
```bash
npm run build
```
The installer will be created in `dist/` as a Windows NSIS setup executable.
