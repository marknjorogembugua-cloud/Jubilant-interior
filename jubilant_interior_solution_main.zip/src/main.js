const {app,BrowserWindow,ipcMain,dialog}=require("electron");
const fs=require("fs"),path=require("path");
const dataPath=path.join(app.getPath("userData"),"data.json");
function load(){const defaults={settings:{businessName:"Jubilant Interior Solution",tagline:"Interior Design • Space • Detail",phone:"",email:"Jarruljone@gmail.com",website:"",address:"",prefix:"QT",paymentDetails:"",footer:"Thank you for choosing Jubilant Interior Solution."},clients:[],projects:[],catalog:[],quotes:[]};try{const d=JSON.parse(fs.readFileSync(dataPath,"utf8"));d.settings={...defaults.settings,...(d.settings||{})};d.clients=d.clients||[];d.projects=d.projects||[];d.catalog=d.catalog||[];d.quotes=d.quotes||[];return d}catch{return defaults}}
function save(d){fs.mkdirSync(path.dirname(dataPath),{recursive:true});fs.writeFileSync(dataPath,JSON.stringify(d,null,2))}
let db;
function createWindow(){const w=new BrowserWindow({width:1440,height:920,minWidth:1100,minHeight:700,backgroundColor:"#f7f7f7",webPreferences:{preload:path.join(__dirname,"preload.js"),contextIsolation:true,nodeIntegration:false}});w.loadFile(path.join(__dirname,"index.html"))}
app.whenReady().then(()=>{db=load();createWindow();app.on("activate",()=>BrowserWindow.getAllWindows().length||createWindow())});
app.on("window-all-closed",()=>{if(process.platform!=="darwin")app.quit()});
ipcMain.handle("db:get",()=>db);
ipcMain.handle("db:save",(e,next)=>{db=next;save(db);return db});
ipcMain.handle("db:backup",async()=>{const r=await dialog.showSaveDialog({title:"Backup Interior Quote Manager",defaultPath:"interior-quote-manager-backup.json",filters:[{name:"JSON Backup",extensions:["json"]}]});if(!r.canceled)fs.writeFileSync(r.filePath,JSON.stringify(db,null,2));return !r.canceled});

ipcMain.handle("pdf:export",async(e,html)=>{
 const r=await dialog.showSaveDialog({title:"Export Professional Quotation PDF",defaultPath:"quotation.pdf",filters:[{name:"PDF Document",extensions:["pdf"]}]});
 if(r.canceled)return {ok:false};
 const pdfWin=new BrowserWindow({show:false,width:900,height:1200,webPreferences:{sandbox:true}});
 try{
   const logo=path.join(__dirname,"../assets/jubilant-logo.png");
   if(fs.existsSync(logo)){const b64=fs.readFileSync(logo).toString("base64");html=html.replace(/src="file:[^"]+jubilant-logo\.png"/i,`src="data:image/png;base64,${b64}"`);}
   await pdfWin.loadURL("data:text/html;charset=utf-8,"+encodeURIComponent(html));
   const data=await pdfWin.webContents.printToPDF({printBackground:true,pageSize:"A4",margins:{top:0,bottom:0,left:0,right:0},preferCSSPageSize:true});
   fs.writeFileSync(r.filePath,data);
   return {ok:true,path:r.filePath};
 }catch(err){return {ok:false,error:String(err)};}finally{pdfWin.close();}
});
ipcMain.handle("db:restore",async()=>{const r=await dialog.showOpenDialog({title:"Restore backup",properties:["openFile"],filters:[{name:"JSON Backup",extensions:["json"]}]});if(r.canceled)return false;try{db=JSON.parse(fs.readFileSync(r.filePaths[0],"utf8"));save(db);return db}catch{return false}});
